(function(){
var SP=/*SPRITES*/{},AS=/*ASPECT*/{},M=window.__md;
var tr=document.getElementById('lkTrack');if(!tr||!M)return;
var LOOKS=[['purple','ست بنفش نرم',[101,102]],['grayman','ست روزمره',[103,104,105]],['blackcoat','کت مشکی شهری',[106,107]],['maroon','ست پاییزی',[108]],['younggray','استایل خاکستری',[109,110,111]],['navydrape','شب سرمه‌ای',[112]]];
var N=LOOKS.length,row=document.getElementById('lkRow'),cur=0,tgt=0,act=-1,focus=false,selP=null;
var PIN=[[[50,28],[30,94]],[[24,56],[50,74],[48,96]],[[50,36],[50,94]],[[50,50]],[[35,30],[50,66],[45,95]],[[45,45]]];
var els=LOOKS.map(function(L,i){var d=document.createElement('div');d.className='lk-m';d.style.aspectRatio=String(AS[L[0]]||.27);
 var im=new Image();im.src=SP[L[0]];im.alt=L[1];im.draggable=false;d.appendChild(im);
 L[2].forEach(function(id,k){var b=document.createElement('button');b.className='lk-pin';b.textContent=M.fa(k+1);b.style.left=PIN[i][k][0]+'%';b.style.top=PIN[i][k][1]+'%';b.setAttribute('aria-label','قطعه '+(k+1));b.addEventListener('click',function(e){e.stopPropagation();select(id)});d.appendChild(b)});
 d.addEventListener('click',function(){if(i===act){setFocus(!focus)}else{go(i)}});row.appendChild(d);return d});
var seg=document.getElementById('lkSeg');
LOOKS.forEach(function(L,i){var b=document.createElement('button');b.setAttribute('aria-label',L[1]);b.addEventListener('click',function(){go(i)});seg.appendChild(b)});
function range(){return tr.offsetHeight-document.getElementById('lkStage').offsetHeight}
function go(i){setFocus(false);var y=tr.getBoundingClientRect().top+scrollY+range()*(i/(N-1));scrollTo({top:y,behavior:'smooth'})}
document.getElementById('lkPrev').addEventListener('click',function(){go(Math.max(0,act-1))});
document.getElementById('lkNext').addEventListener('click',function(){go(Math.min(N-1,act+1))});
document.getElementById('lkX').addEventListener('click',function(){setFocus(false)});
function setFocus(v){focus=v;tr.classList.toggle('focus',v);document.getElementById('lkX').hidden=!v;document.getElementById('lkHint').hidden=!v;if(!v){selP=null;render()}else{selP=null;render()}}
function select(id){selP=selP===id?null:id;render()}
function render(){var L=LOOKS[act],list=document.getElementById('lkList');if(!L)return;
 document.getElementById('lkNo').textContent='ست '+M.fa(('0'+(act+1)).slice(-2));document.getElementById('lkName').textContent=L[1];
 document.getElementById('lkCnt').textContent=M.fa(L[2].length)+' قطعه';
 var tot=0;list.innerHTML=L[2].map(function(id,k){var p=M.byId(id);tot+=p.price;var sel=selP===id;
  return '<div class="lk-it'+(sel?' sel':'')+'" data-id="'+id+'"><button class="th" aria-label="'+p.name+'">'+M.art(p)+'<i>'+M.fa(k+1)+'</i></button><div><small>'+p.brand+'</small><h4>'+p.name+'</h4><div class="p">'+M.money(p.price)+'</div></div><button class="pl" aria-label="انتخاب">'+(sel?'×':'+')+'</button><div class="lk-sz">'+p.sizes.map(function(s,j){return '<button class="s'+(j===0?' on':'')+'" data-s="'+s+'">'+s+'</button>'}).join('')+'<button class="a" data-a="1">افزودن به سبد</button></div></div>'}).join('');
 list.querySelectorAll('.lk-it').forEach(function(it){var id=+it.dataset.id,size=M.byId(id).sizes[0];
  it.querySelector('.th').addEventListener('click',function(){select(id)});it.querySelector('.pl').addEventListener('click',function(){select(id)});
  it.querySelectorAll('.s').forEach(function(b){b.addEventListener('click',function(){size=b.dataset.s;it.querySelectorAll('.s').forEach(function(x){x.classList.toggle('on',x===b)})})});
  it.querySelector('.a').addEventListener('click',function(){M.addToCart(id,size)})});
 els.forEach(function(e,i){e.querySelectorAll('.lk-pin').forEach(function(b,k){b.classList.toggle('on',i===act&&selP===LOOKS[i][2][k])})});
 document.getElementById('lkSave').textContent=L[2].length>1?'هر '+M.fa(L[2].length)+' قطعه با ۱۰٪ تخفیف':'با ۱۰٪ تخفیف ست';document.getElementById('lkOld').textContent=M.money(tot);document.getElementById('lkNew').textContent=M.money(Math.round(tot*.9/1000)*1000);
 [].forEach.call(seg.children,function(b,i){b.classList.toggle('on',i===act)})}
document.getElementById('lkAll').addEventListener('click',function(){LOOKS[act][2].forEach(function(id){M.addToCart(id,M.byId(id).sizes[0])})});
function prog(){var r=tr.getBoundingClientRect(),R=range();return Math.min(1,Math.max(0,-r.top/Math.max(1,R)))}
function tick(){var W=row.offsetWidth,t=prog()*(N-1);tgt=t;cur+=(tgt-cur)*.14;if(Math.abs(tgt-cur)<.001)cur=tgt;
 var a=Math.round(cur);if(a!==act){var was=act;act=a;if(focus&&was!==-1)setFocus(false);else render()}
 var narrow=W<700,gap=W*(narrow?.3:.2);
 els.forEach(function(e,i){var d=i-cur,ad=Math.abs(d),x=Math.sign(d)*Math.pow(ad,.8)*gap*1.25,s=1-.1*Math.min(ad,2.5),bl=ad<.12?0:Math.min(ad,3)*2.4,op=Math.max(0,1-.3*Math.max(0,ad-.7));
  if(focus){if(i===act){x=0;s=1.1;bl=0;op=1}else op=0}
  e.style.transform='translateX(calc(-50% + '+x+'px)) scale('+s+')';e.style.filter=bl?'blur('+bl.toFixed(1)+'px)':'none';e.style.opacity=op;e.style.zIndex=100-Math.round(ad*10);e.style.pointerEvents=op<.05?'none':'auto'});
 requestAnimationFrame(tick)}
tick();
})();
